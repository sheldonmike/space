(function() {
  $(window).ready(function() {
    $('.cloud').playKeyframe('clouds 40s linear 0 infinite');
    $('.balloon').playKeyframe('balloon 40s ease 0 infinite');
    $('.sun').playKeyframe('sun 40s linear 0 infinite');
  });

}).call(this);
